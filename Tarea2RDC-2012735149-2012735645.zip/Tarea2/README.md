# Tarea2RC

* **José Miguel Castro** 			201273514-9
* **Felipe Ignacio Morales**	201273564-5

# Compilación:

* javac *.java

# Ejecución:

* java Server ( udp | tcp ) 
* java Client ( udp | tcp )
