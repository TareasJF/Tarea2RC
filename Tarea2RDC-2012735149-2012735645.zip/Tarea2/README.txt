# Tarea2RC

José Miguel Castro
	rol: 201273514-9
Felipe Ignacio Morales
	rol: 201273564-5

# Compilación:
		Es necesario java 1.8
	javac *.java

# Ejecución:
		Por permisos de puertos se deben iniciar como root
	java Server ( udp | tcp ) 
	java Client ( udp | tcp )
